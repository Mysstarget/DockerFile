# Interface réseau à surveiller.
# Exemple: eth0, ens18, enp3s0
MONITOR_INTERFACE=wlp1s0
